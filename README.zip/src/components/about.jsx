import '../styles/about.css'
const About = () => {
    return ( 
        <div className="about">
            <h1>
                this is about page
            </h1>
        </div>
     );
}   
 
export default About;