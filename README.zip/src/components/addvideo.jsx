import '../styles/about.css'
const Addvideo = () => {
    return ( 
        <div className="addvideo about">

        </div>
     );
}
 
export default Addvideo;